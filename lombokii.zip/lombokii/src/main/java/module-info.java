module com.example.lomboki_final {
    requires javafx.controls;
    requires javafx.fxml;
    requires static lombok;
    requires java.sql;


    opens com.example.lomboki_final to javafx.fxml;
    exports com.example.lomboki_final;
}