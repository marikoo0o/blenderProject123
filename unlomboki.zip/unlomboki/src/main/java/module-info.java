module com.example.javasfinaluri {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.javasfinaluri to javafx.fxml;
    exports com.example.javasfinaluri;
}